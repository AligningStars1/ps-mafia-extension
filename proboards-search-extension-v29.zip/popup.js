(function () {
  const DEFAULT_SETTINGS = {
    enableSearchIso: true,
    enableMultiQuote: true,
    enableRefresh: true,
    enableNotes: true,
    enableShowUsername: true,
    enableDayFilter: true
  };

  const keys = Object.keys(DEFAULT_SETTINGS);
  const toggleBtn = document.getElementById("toggle-options-btn");
  const optionsPanel = document.getElementById("options-panel");
  const saveStatus = document.getElementById("save-status");

  toggleBtn.addEventListener("click", () => {
    const isOpen = optionsPanel.classList.toggle("open");
    toggleBtn.textContent = isOpen ? "⚙️ Hide Options ▲" : "⚙️ Options";
  });

  function loadSettings() {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(["pb_mafia_settings"], (res) => {
        const current = Object.assign({}, DEFAULT_SETTINGS, res.pb_mafia_settings || {});
        keys.forEach((k) => {
          const el = document.getElementById(`opt-${k}`);
          if (el) el.checked = Boolean(current[k]);
        });
      });
    }
  }

  function saveSettings() {
    const updated = {};
    keys.forEach((k) => {
      const el = document.getElementById(`opt-${k}`);
      updated[k] = el ? el.checked : true;
    });

    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ pb_mafia_settings: updated }, () => {
        saveStatus.textContent = "✓ Preferences saved & applied!";
        setTimeout(() => {
          saveStatus.textContent = "";
        }, 2000);
      });
    }
  }

  keys.forEach((k) => {
    const el = document.getElementById(`opt-${k}`);
    if (el) {
      el.addEventListener("change", saveSettings);
    }
  });

  loadSettings();
})();
