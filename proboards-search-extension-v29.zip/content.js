(function () {
  const REFRESH_ICON_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAGhElEQVR4nO2bXYhVVRTHf/fODOOo2YgaWkmlE5nTN2WfUIEFIUgghKEkvfTSSw/5EOFjGSX2EL30IlREGFEvglCUJqFiQl9UU5ZRFmaGk43WzNyPHvb6s/fZ99w7c71f547+4XDuOXvvdf5r7bX3XvvjwgW0HDkgb/fzDvkpns8L9ANXB889nSLSTsjlrwO+BsaBfcAKS+/tEK+2QbX8LlAGCnb/C1gb5Jmx/YIMsAun+DjeCGXgmSDvjOwX1ATuBsZwSheBkt3LwJvAHMs/I/sFKXUb8A3eCGVg0u6HgCHLN2M8IU9ljV4FjJD0ABnhD+D+oGzXIkdS8UHgUeB94GfgLL4P0CUj/AksNBld2TGGig8BLwDHqFQ47ZJH3GLlu84LpPzFwHPAP3jlCsCEXUWqK/8FMECXeYBifICHgO9JuvYkyaGvjB8Ryrj+oIAzwj0mp2tGg9BNnyepeJGk4r8CrwEPAnvwNa88201O1yk/G3gPr1Cs+H7gMWC+5V+LbxZy/RGT0zVRoQKcecDH+Fov4Xv034DHSSq0FBcGaxiUoe6z9K6ofbX5PuADnAITJMf2d4AlQf5+u79Msm8oA69Yvq6ZGKmWXidd+WeDvL3R/W3Lo1jgJ2AuXbRQIuWfIqm8XPmJIF8+Kqc5wajlPQXcG8nNNETyJvzQFrZ5Kd9Hem3q3XJgHXClPbci4BHXcIhuGIrtP8X34qr5rZanbxoyaj03A7WMf85QG95ApfJ77AO90/yQDNkK5SVzI/A58Alwa5RWNxSW9gPfkozczgDXNPqBJkHfv5Fk1PkjMIsGwmvV/iNUd/0sDGFq9w/jO+gJ+73B0s6Jp4aovfhOrwScABaQnYmLOCzAcQuDs72WVreXqsC1VPb6L1paFmpfEJeXqIxOtRJdlxEkcHMksAAM0+RhpgkIK0wxiipss6XVVWESuBu/qlsGDpMd148hTgdJct5t71MrLO1lDmfBObiNjRAfmdAsRnDi9GH0/nrcjLNESsVVMwDAFfiJjYTvb4xjW3DI7uK8GKcL1GmAyy29aMI0fwdnzaxBnH6w3z047nncqjTUaYBLI8GjuCVscMbIGsTpOPC3/Rb3cIqeQK2efG70fAY3nc06zuK4gjfKvGqZaxlgIBKimWDWUcRxDVF1slbLAHE7b9VEptlI25kq1spcDWN2V7sZwE2Mso5+vPeK+1iVvDUNcCISMggsit5lCeK0CMc1fHeiIrchzQBy/WN277F3fdQYTzOAMH7pww+F4HWpGL7TDKBO7yhuOMnh29DNZDsUzuE4guOcw+lw1N5VDN/VDJADTuIDHxVcjd/WyhpKOG6r7VmcR3C65JimAcC7zj68QQDuwgUVpRplO4E8jtMSHEfwCu+z59T5SzUlZKld+H3/AnARbmW3VtlOQFzW4TgW8Evyuyytrug1XA88QnJ+/RU+JshCX6C1iR4ct3D94gh+d6purlpA2BII1ZrgekvLwrRYHNbj1y5VWVss7ZzXBAEuA07jV4RKuBXXLOzqqnnONk4hx9M47tBAc5V1t1HpBdrXn2pTpJXQt7dTWfvbLK0hL1XbWYibZsbnAHTqsxMLpPpmfO6giOPatENXsuBGkqdAiriNzuGIUDugbw0bB/FR7W+09Kb1URK0k6QRysAv+KXndjQHfWOFfVsnVKT8TktvagetoWYQF1nFR11+B1YFH27V/p+UWmXfjM8bjRjHlgzRUmol7rhLbIQxYFOQf7qbplNBG7DCJpLnj8OT6Csjrk2HauAO/IGH0Ahl4C1gWVSm3uFSw1voxstMdnjGUMqPGidoQ2yi2gjdMNw5EqGtuMNRIfJWvhevoC69j2tvqckaxRs8jEzD5te2jlhWXo7fiVGNhEflTgE7cAcpB+uQP2hldpgMyZN8edxB4xByqguNtFGtu8/CBR1P2nutHZRJ1shx3N9nvgS+w63S/GtpA8AluJ79BtyO1OKgbCHgKkVfBZ4G/gu4tB2huz4AHCDZRiepfk54qqtoZSej8gfsW2kcOoLwmHweF4QcJl2ZcbukmFx6MiU9Ntphky2FOz0PqUBP9HsN8AbO9eutfV3HTcaaFPlNQSssGLfH+cDtwJ24g0tDuDh9Dr6PKOB2c07i5vCf4TZiD+I6wWqyG0arXCg8QBET7sH18nPx+wzjuOBmtEp+8Gt+TUU72lD43+ESUy+o5u3S4mtLN2I70YnkortQju4X0A78D8iWLb3a5GOwAAAAAElFTkSuQmCC";
  const NOTES_ICON_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAKmElEQVR4nO2bfZCXVRXHP/vbZdeXFleFESPlZXCILMR0jQolEqd3g4rG7BVysBcHatxiVZjBDHvRmLQMS4MRrcRCTLR8qSSBoqiomLAXI1QInYg2iATZ3V9/nHv2nt/93fs8z293gZ30O/PM/rjPvec559xzzz3n3Au8gOc36o40AwnU43krA93u7/896oBS4l2qPexTX+sHBwrq8LPcCrwGOBb4I/AQ8B9EwO5gTMn97eIwWMmhUlidewYDK/Amr89fgTe6vg3uiVnEKcDEQ8WnfrDOMWDXaX/QbgB+hBd6P7Db/PsgIpzF8cDrgWuANcC/XN8r3fuGfuKvB8dE2pT53ipEmXwvXti7gXHAMOBSxPzLwM+As4HLgXuBHVRaijrM3+Otqs9QpzID2A6sBT4LTAVOSPRPmWgMqrxVyDreCjQFfa5FBOukWuAysBd4BHgUbz2j3NiifCShBNZFPrwTuA/4FHAOcFRkfGgd6ri0XfGwo3mP+3cT0OieN+CXQRl4DtgMfB24CBjtxrQa3t5nvt9rKNNDgA5khnYA/yQ+E38GbgdmAmMz6FkcB0wGfufo/420BRwA2oDTqd7u6oBmxErLwDLX3icF6EfeihfyQmRtXgQsQdbbAaqVcdAJ9RVgOvBiQ3MCcBmwEngyMnYV3gd8BO8D1kf4q6dy/1/p+v4JGOTaeu0LVHuLHdHdwNCgTwmZkY8C30VmMLZW9yD+Y3Pi/X+BJ/BbYGoXqHeChUIpr5e5/p3AGYbHXkE96UZH9MfmY42IqYbES8DbkG3pIPCsEyYUuBPYAiwFPohYyPWRfmXgcXwckBcpvgLvK+YYfmuGEhyFzE4ZWIB3YBbNwHnAfOAHiCffFxHkKWSLm4Msg0GGxghEWWXg567PfGT5vCjgKQsNwGNUOtSawmNLCOD9+P31XEPwdGA2cCcicGzm/g38FLgamII4vBCN7u+9eMs4K9KvqPAAtzpaO/DKq9kPKLFlhtjRwHjgt8TX8bPAr4AbgGl4x2dh4wT9xlsMvW+6tiZqD7CU3sWGp8nmu4WhHxyEeNMy8H3XNh/vlPa798vJ3vpSgijD1ziaHcDJiHJ647h0zAj8ElwYfKsmQhPwMzMHEWCKa+sGrqJ6z9aPFZk5fX8C8Bkkrrff7w2U5i8Qvh/pDU3V1lz8bI93bTbYuNm1qbn2OeykmLmH0aQ1b+X9OrxVnVQDbTAE73FEtlApoAYbf8E7sb4kHnaZpBALn2PQ92/C+4Fprq1qGcRmTIsLzUh8D5KFdeKF/Yn7OwqJ2HRcb6HevyvgQx1mHT4Z6nJt45HgawV+edqCyS+RkB380ioE1eDr8Bq82LWpAvot2DCwAscmZhSSMt8K/IHqXeh4Q0fHP+jebcJXjnKhglztBu8DTnVtJdNHg41Vrq3WYCOVFSqGIGb8RSQw2ks833gMaKdy51AZrsCH1WMCGZLQDmvc4A2GYUtcg42/I8vF9smirbMc4hjg1Y7pB4BniAdX2xHfNBc4E2+VVon6eyI+t5gZ8B+FCjAM8Z5lZAbswFqDDbuOLUrAy5Bo8jtI3S8m8G7E5yxEtuCWLAECOY5GEqwykqaneOyBCjfNMKBJiA7sS7BxClJZykqj9wO/oTqNTqGE+KRzg3bldwU+odKYJWmpKsCNbtAu4MTIIP29wfVbY5gJ+5wPLELKVR2kCynLgVnAS7MYdDiVSkVqtmnNXGW51L3rwucYSStQx7TJDXogIph+ANLBhr6flxB4J7Aaqe60Ei+lWZwIXIAoci1xRXYjRRoVUHkeh5TQykgx1fJfAR1wGl6j7YkBecGG9v80fh0/SnYx1eIoRDGXI4raGRFYFak1yVe6saGl1iNFmLLra2WtgDI9C69RrcPH6m84QXa5/jcGdBSvQvxFHsa6b9+OLIlUer0WsYSYIsOjNeXlZjf+aXxKXrXMVMg7XOdtiBeNdqaPwQbi3KYjqfOv8cUQ+xxA6opLgHdTTJEWqoAZhub5rq1iUpXpJvx2dGesY4R4O+lgwx5OHIdElwuRDM3W++yz1X17NrJN5gVYwxFFfhkJmObjLaFk+mggtSjgv0LIs/GHjLNjHSNjsoKNOmQ934TPIMPnGcTZtiOB0LE5AreQrcg9VFaDdQLWu/frzLseKMNtrtNz+CQnFTraYGMb1cGGjhsTMLgXmanrECcaVplDNCIR31wk7H6KuCKfRhR5YcC3ynYtXkHDQ9n0x32u02aKFTTygg31wm3AN4D34I+ssjAGqUUuRWJ9tcqUIt9MWpHK41QzdoZra1BGQdaoxt9LbIcMZAUbtRRHTkJK6V9CKjmxinInkgXegoThoyN0YhckVL4WEvLlaigDRYON0JqagUlISe0h4B/EzfoJ4HvIYccZCX6KlN+Uz/uJWHi4RvYSWSMZyAs2dCk040+PthEXeBdyR2ABcs4wOPK9Wk+fIe7jegq4hbxkAeJL8F7dBhv6finVAu9DKjeL8WeOKfTlQkZsl7vEdhiOP4CM7pMZiAUbU82H9ePzEOvagpw1fAAJu/MwGhjpfvdWAbE451u2wzuJM18EhYMNJB2OldEthiD3AT6PWOVeZHJag+/VijDSfRwf6fJVvPm2uLZatK199RJFbBml6GklqB34IbKfx/zDeYEgtUKLMpfgd5XXKsFNFMiWcohDtiO1ChjnGPk22ZWgNcip0cQIjaJQJ93ofo/AH/YuBDnk1ESkLRCoKGJb6bsMLd0JhiLha6oStAmpBL0Dr8BaYYutqat0W5HwfT1IWbvsGlrxZ/+9WQItxIMNVZC9w1NGDlbuAD6MD71DukUOQ7Kqyy1IBmiv0tmSOqsR4bcSv+xQ9JwvK9iwz0ykUNKKcUIG+r2sZWjPEEI0IdvdJ0lfpSsjwddNIEFBF/4KyyKk/JR3BS510ltLQpVHU5F3aHIa8CHgNuS0OrxpqknQeuBzyC6jtc6e6y/ho+WmNvKvwNkYPC+lbiDfqvIOTU4G3o7UADbinZp9wqt0IyN0SjjBilRudb1q5TZGrAHZ1vTGSF5RJTY+1ncwsg0uQO4ppa7pbQPuAj4GvDxCK+uuQg+0dv815CZIXu0+5rFvMwylympZ67gBf5XubrLX8YNIUjUJfx0mpJX0KeqYdP2FV87rkHU8CTmVOYd4GtqB1O7WItndBKTWB3LtfYNjpIw/6e0OaIxGAqIp7u9YqmdwH5ISr0O2043IrmOhs2v9QE0ocn43D4naUud3u/CWcwVxkxuK3A26HlFQ7PCzE1nfXU7oVA2g6E5VM4qe4H4BuUOwh2ohHnZ9m5HQ80rXllrH25HS18eRpahnFJ9wdAZxCAXOQ952NBKp1tyCCNKFLI+VxK/SdSIzfz8SkJ1FZVFUr+h1IbtLrOJzRBHe4rCYjo8wYzNtFbAamfEzqfw/CXfhM7fcg82BgBLeRIcgdwfKyP/7WY4kQFchx90dxJXyJFIGm+N+dyPbLwyw2c+CztJLkDO7xkifYUghdDFSFYoVQg8gCpjlxtSapB1RhKaqSyXlP8YgVaJliMXYhEW9f39cw8tksr+hDMf2Yxt/dAbvGpE0fTJSL1jt+tW8p+dhIDkUPctTr39YMJAUYGEj1MOqkBfwfMP/ALKVofDHwnp5AAAAAElFTkSuQmCC";

  const DEFAULT_SETTINGS = {
    enableSearchIso: true,
    enableMultiQuote: true,
    enableRefresh: true,
    enableNotes: true,
    enableShowUsername: true,
    enableDayFilter: true
  };

  let currentSettings = Object.assign({}, DEFAULT_SETTINGS);

  function applySettingsClasses(settings) {
    currentSettings = Object.assign({}, DEFAULT_SETTINGS, settings || {});
    const root = document.documentElement;
    if (!root) return;
    root.classList.toggle("pb-hide-search-iso", !currentSettings.enableSearchIso);
    root.classList.toggle("pb-hide-mq", !currentSettings.enableMultiQuote);
    root.classList.toggle("pb-hide-refresh", !currentSettings.enableRefresh);
    root.classList.toggle("pb-hide-notes", !currentSettings.enableNotes);
    root.classList.toggle("pb-hide-username", !currentSettings.enableShowUsername);
    root.classList.toggle("pb-hide-day-filter", !currentSettings.enableDayFilter);
  }

  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["pb_mafia_settings"], (res) => {
      applySettingsClasses(res.pb_mafia_settings);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.pb_mafia_settings) {
        applySettingsClasses(changes.pb_mafia_settings.newValue);
      }
    });
  }

  function initExtension() {
    if (document.getElementById("pb-mafia-bottom-bar")) return;

    const isThreadPage =
      /\/(?:thread|post\/new|quote)\//i.test(window.location.pathname) ||
      window.location.pathname.includes("/thread/");
    const threadIdMatch = window.location.pathname.match(/\/(?:thread|post\/new|quote)\/(\d+)/i);
    const threadId = threadIdMatch ? threadIdMatch[1] : null;
    const currentThreadKey = threadId
      ? `pb_mq_thread_${threadId}`
      : `pb_mq_url_${window.location.pathname.replace(/[^a-zA-Z0-9]/g, "_")}`;

    // Persistent cache for resolved numeric user IDs -> @username handles
    const USER_MAP_STORAGE_KEY = "pb_mafia_resolved_usernames_v1";
    let usernameCache = {};
    try {
      const savedMap = localStorage.getItem(USER_MAP_STORAGE_KEY);
      if (savedMap) usernameCache = JSON.parse(savedMap) || {};
    } catch (e) {}

    function saveUsernameCache() {
      try {
        localStorage.setItem(USER_MAP_STORAGE_KEY, JSON.stringify(usernameCache));
      } catch (e) {}
    }

    // Clean thread title extractor for automatic Thread Note Folders
    function getCleanThreadTitle() {
      const navLinks = document.querySelectorAll("#navigation-tree a[href*='/thread/']");
      if (navLinks.length > 0) {
        const lastTxt = navLinks[navLinks.length - 1].textContent.trim();
        if (lastTxt) return lastTxt;
      }
      const titleBarH1 = document.querySelector(".container.posts .title-bar h1, .title-bar h1, .title-bar h2");
      if (titleBarH1) {
        const t = titleBarH1.textContent.trim();
        if (t) return t;
      }
      const docTitle = (document.title || "").split("|")[0].trim();
      return docTitle || (threadId ? `Thread #${threadId}` : "General Thread");
    }

    // IndexedDB helper for scanned thread pages
    const IDB_NAME = "pb_mafia_iso_cache_v3";
    const IDB_STORE = "thread_pages";
    let dbPromise = null;

    function openIsoCacheDB() {
      if (dbPromise) return dbPromise;
      dbPromise = new Promise((resolve) => {
        try {
          const req = indexedDB.open(IDB_NAME, 1);
          req.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains(IDB_STORE)) {
              db.createObjectStore(IDB_STORE);
            }
          };
          req.onsuccess = (e) => resolve(e.target.result);
          req.onerror = () => resolve(null);
        } catch (err) {
          resolve(null);
        }
      });
      return dbPromise;
    }

    async function getCachedPagePosts(pageNum) {
      if (!threadId) return null;
      const db = await openIsoCacheDB();
      if (!db) return null;
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(IDB_STORE, "readonly");
          const store = tx.objectStore(IDB_STORE);
          const req = store.get(`${threadId}_p_${pageNum}`);
          req.onsuccess = () => resolve(req.result || null);
          req.onerror = () => resolve(null);
        } catch (e) {
          resolve(null);
        }
      });
    }

    async function setCachedPagePosts(pageNum, posts) {
      if (!threadId) return;
      const db = await openIsoCacheDB();
      if (!db) return;
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(IDB_STORE, "readwrite");
          const store = tx.objectStore(IDB_STORE);
          store.put(posts, `${threadId}_p_${pageNum}`);
          tx.oncomplete = () => resolve();
          tx.onerror = () => resolve();
        } catch (e) {
          resolve();
        }
      });
    }

    function cleanMessageClone(rootEl) {
      const clone = rootEl.cloneNode(true);
      clone
        .querySelectorAll(
          ".content-head, .control-bar, .controls, .options, .ui-selectMenu-box, .foot, .signature, .edited_by, script, style"
        )
        .forEach((el) => el.remove());
      return clone;
    }

    function sanitizeRawQuoteText(str) {
      if (!str) return "";
      return str
        .replace(/Select PostDeselect PostLink to PostReport PostMemberSend MessageGive GiftBack to Top/gi, "")
        .replace(/^\s*Quote\s*$/gm, "")
        .replace(/^\s*Post by .*? on .*?GMT.*?$/gm, "")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
    }

    // Detect host's [code]Day X[/code] announcement while ignoring any quoted posts
    function detectAnnouncedDayFromUnquotedMessage(cleanedMessageClone) {
      if (!cleanedMessageClone) return null;
      const unquoted = cleanedMessageClone.cloneNode(true);
      unquoted.querySelectorAll("blockquote, .quote, .pb-quote-box").forEach((q) => q.remove());

      const codeBlocks = unquoted.querySelectorAll("code, pre, .code");
      for (const cb of codeBlocks) {
        const raw = (cb.textContent || "").trim();
        if (raw.length > 0 && raw.length <= 60) {
          const m = raw.match(/^day\s+(\d+)\b/i);
          if (m && m[1]) {
            const d = parseInt(m[1], 10);
            if (!isNaN(d) && d >= 1 && d <= 50) {
              return d;
            }
          }
        }
      }

      const rawText = unquoted.textContent || "";
      const rawMatch = rawText.match(/\[code\]\s*day\s+(\d+)\b[^\[]*\[\/code\]/i);
      if (rawMatch && rawMatch[1]) {
        const d = parseInt(rawMatch[1], 10);
        if (!isNaN(d) && d >= 1 && d <= 50) {
          return d;
        }
      }

      return null;
    }

    function getMqQueue() {
      try {
        const raw = localStorage.getItem(currentThreadKey);
        if (!raw) return [];
        const parsed = JSON.parse(raw);
        return parsed.map((item) => ({
          ...item,
          bbcode: sanitizeRawQuoteText(item.bbcode)
        }));
      } catch (e) {
        return [];
      }
    }

    function saveMqQueue(queue) {
      try {
        localStorage.setItem(currentThreadKey, JSON.stringify(queue));
      } catch (e) {
        console.error("Failed to save MQ queue:", e);
      }
      updateMqUI();
    }

    function htmlToBBCode(htmlString, stripNestedQuotes = true) {
      const temp = document.createElement("div");
      temp.innerHTML = htmlString;

      temp
        .querySelectorAll(
          ".content-head, .control-bar, .controls, .options, .ui-selectMenu-box, .foot, .signature, .edited_by, script, style"
        )
        .forEach((el) => el.remove());

      if (stripNestedQuotes) {
        temp.querySelectorAll("blockquote, .quote").forEach((q) => q.remove());
      } else {
        temp.querySelectorAll("blockquote, .quote").forEach((q) => {
          const inner = q.textContent.trim();
          q.replaceWith(`\n[quote]${inner}[/quote]\n`);
        });
      }

      temp.querySelectorAll("img").forEach((img) => {
        const src = img.getAttribute("src");
        if (src) {
          img.replaceWith(`[img]${src}[/img]`);
        }
      });

      temp.querySelectorAll("a").forEach((a) => {
        const href = a.getAttribute("href");
        const txt = a.textContent.trim();
        if (href) {
          a.replaceWith(`[url=${href}]${txt || href}[/url]`);
        }
      });

      temp.querySelectorAll("b, strong").forEach((el) => {
        el.replaceWith(`[b]${el.innerHTML}[/b]`);
      });
      temp.querySelectorAll("i, em").forEach((el) => {
        el.replaceWith(`[i]${el.innerHTML}[/i]`);
      });
      temp.querySelectorAll("u").forEach((el) => {
        el.replaceWith(`[u]${el.innerHTML}[/u]`);
      });
      temp.querySelectorAll("s, del, strike").forEach((el) => {
        el.replaceWith(`[s]${el.innerHTML}[/s]`);
      });
      temp.querySelectorAll("br").forEach((el) => {
        el.replaceWith("\n");
      });
      temp.querySelectorAll("p, div").forEach((el) => {
        el.prepend(document.createTextNode("\n"));
      });

      return sanitizeRawQuoteText(temp.textContent || "");
    }

    function parseAuthorAndUsername(postEl) {
      const authorEl = postEl.querySelector(".mini-profile .user-link, .mini-profile .name, .user-link, .name, .user-guest");
      const authorName = authorEl ? authorEl.textContent.trim() : "Unknown";

      let usernameAttr = "";
      let numericUserId = null;
      const userLink = postEl.querySelector(".mini-profile .user-link, .user-link, a[href*='/user/']");
      
      if (userLink) {
        const title = userLink.getAttribute("title") || "";
        const titleMatch = title.match(/@([a-zA-Z0-9_-]+)/);
        if (titleMatch && titleMatch[1] && !/^\d+$/.test(titleMatch[1])) {
          usernameAttr = `@${titleMatch[1].trim()}`;
        } else {
          const classes = Array.from(userLink.classList);
          for (let c of classes) {
            if (c.startsWith("user-") && c !== "user-link" && !/^\d+$/.test(c.replace("user-", ""))) {
              usernameAttr = `@${c.replace("user-", "").trim()}`;
              break;
            }
          }
          if (!usernameAttr) {
            const href = userLink.getAttribute("href") || "";
            const hrefMatch = href.match(/\/user\/([^\/\?#]+)/i);
            if (hrefMatch && hrefMatch[1]) {
              const slug = hrefMatch[1].trim();
              if (/^\d+$/.test(slug)) {
                numericUserId = slug;
                if (usernameCache[slug]) {
                  usernameAttr = usernameCache[slug];
                } else {
                  usernameAttr = `@${slug}`;
                }
              } else {
                usernameAttr = `@${slug}`;
              }
            }
          }
        }
      }

      if (!usernameAttr && authorName !== "Unknown") {
        usernameAttr = `@${authorName.toLowerCase().replace(/\s+/g, "")}`;
      } else if (!usernameAttr) {
        usernameAttr = "@unknown";
      }

      return { author: authorName, username: usernameAttr, numericUserId, authorEl: authorEl || postEl };
    }

    const pendingUserResolutions = {};

    async function resolveUsernameFromUserId(userId, fallbackName) {
      if (!userId) return `@${(fallbackName || "user").toLowerCase().replace(/\s+/g, "")}`;
      if (usernameCache[userId]) return usernameCache[userId];
      if (pendingUserResolutions[userId]) return pendingUserResolutions[userId];

      pendingUserResolutions[userId] = (async () => {
        try {
          const res = await fetch(`${window.location.origin}/user/${userId}`, { credentials: "same-origin" });
          const html = await res.text();
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, "text/html");

          const docTitle = doc.title || "";
          const titleMatch = docTitle.match(/\(([^)]+)\)/);
          if (titleMatch && titleMatch[1] && !titleMatch[1].includes(" ")) {
            const found = `@${titleMatch[1].trim()}`;
            usernameCache[userId] = found;
            saveUsernameCache();
            updateResolvedUsernameInDOM(userId, found);
            return found;
          }

          const bodyText = doc.body.textContent || "";
          const textMatch = bodyText.match(/Username:\s*([a-zA-Z0-9_-]+)/i);
          if (textMatch && textMatch[1]) {
            const found = `@${textMatch[1].trim()}`;
            usernameCache[userId] = found;
            saveUsernameCache();
            updateResolvedUsernameInDOM(userId, found);
            return found;
          }
        } catch (e) {
          console.error("Failed to fetch profile for user", userId, e);
        }

        const cleanFallback = `@${(fallbackName || "user").toLowerCase().replace(/\s+/g, "")}`;
        usernameCache[userId] = cleanFallback;
        saveUsernameCache();
        updateResolvedUsernameInDOM(userId, cleanFallback);
        return cleanFallback;
      })();

      const result = await pendingUserResolutions[userId];
      delete pendingUserResolutions[userId];
      return result;
    }

    function updateResolvedUsernameInDOM(userId, resolvedHandle) {
      document.querySelectorAll(`[data-pb-uid="${userId}"]`).forEach((el) => {
        el.textContent = resolvedHandle;
      });
      if (cachedPosts) {
        cachedPosts.forEach((p) => {
          if (p.usernameAttr === `@${userId}`) {
            p.usernameAttr = resolvedHandle;
            p.usernameLower = resolvedHandle.toLowerCase();
          }
        });
      }
    }

    async function buildAllQuotesBBCode() {
      const queue = getMqQueue();
      const resolvedItems = [];
      for (const item of queue) {
        let finalUserAttr = item.usernameAttr;
        if (finalUserAttr && /^@\d+$/.test(finalUserAttr)) {
          const userId = finalUserAttr.replace("@", "");
          finalUserAttr = await resolveUsernameFromUserId(userId, item.author);
        } else if (!finalUserAttr) {
          finalUserAttr = `@${item.author.toLowerCase().replace(/\s+/g, "")}`;
        }
        
        const cleanBody = sanitizeRawQuoteText(item.bbcode);
        let sourcePath = "/thread/1405/forum-bbcode-guide";
        if (item.postId && /^\d+$/.test(String(item.postId))) {
          sourcePath = `/post/${item.postId}/thread`;
        } else if (item.url) {
          try {
            const parsedUrl = new URL(item.url, window.location.origin);
            sourcePath = parsedUrl.pathname + parsedUrl.search;
          } catch (e) {}
        }

        let tsVal = Math.floor(Date.now() / 1000);
        if (item.timestamp) {
          const digits = item.timestamp.match(/\d{10,}/);
          if (digits) {
            tsVal = digits[0];
          } else {
            const parsedDate = Date.parse(item.timestamp);
            if (!isNaN(parsedDate)) {
              tsVal = Math.floor(parsedDate / 1000);
            }
          }
        }

        resolvedItems.push(`[quote author="${finalUserAttr}" source="${sourcePath}" timestamp="${tsVal}"]\n${cleanBody}\n[/quote]`);
      }
      return resolvedItems.join("\n\n") + (resolvedItems.length ? "\n\n" : "");
    }

    // ==========================================
    // Bottom-Left Floating Bar (Search + Refresh + Notes)
    // ==========================================
    const bottomBar = document.createElement("div");
    bottomBar.id = "pb-mafia-bottom-bar";

    const launcher = document.createElement("div");
    launcher.id = "pb-mafia-launcher";
    launcher.innerHTML = `
      <span>🔎Search</span>
      <span id="pb-mq-badge">MQ: 0</span>
    `;

    const refreshBtn = document.createElement("div");
    refreshBtn.id = "pb-mafia-refresh";
    refreshBtn.title = "Load new posts without losing ISO scan progress";
    refreshBtn.innerHTML = `
      <img id="pb-refresh-icon" src="${REFRESH_ICON_DATA_URI}" alt="Refresh" />
      <span id="pb-refresh-toast"></span>
    `;

    const notesBtn = document.createElement("div");
    notesBtn.id = "pb-mafia-notes-btn";
    notesBtn.title = "Open Notes & Folders";
    notesBtn.innerHTML = `
      <img id="pb-notes-icon" src="${NOTES_ICON_DATA_URI}" alt="Notes" />
      <span>Notes</span>
      <span id="pb-notes-badge">0</span>
    `;

    bottomBar.appendChild(launcher);
    bottomBar.appendChild(notesBtn);
    if (isThreadPage) {
      bottomBar.appendChild(refreshBtn);
    }

    function mountLauncher() {
      const target = document.body || document.documentElement;
      if (target && !document.getElementById("pb-mafia-bottom-bar")) {
        target.appendChild(bottomBar);
      }
    }
    mountLauncher();

    // ==========================================
    // Notes & Folders System (#pb-notes-panel)
    // ==========================================
    const NOTES_STORAGE_KEY = "pb_mafia_notes_folders_v1";
    const notesPanel = document.createElement("div");
    notesPanel.id = "pb-notes-panel";
    (document.body || document.documentElement).appendChild(notesPanel);

    let notesFolders = [];
    // currentNotesView: null = All Folders view, or folder object / virtual thread folder id
    let activeFolderId = null;
    let editingNoteId = null;

    function loadNotesData(callback) {
      try {
        const localRaw = localStorage.getItem(NOTES_STORAGE_KEY);
        if (localRaw) {
          notesFolders = JSON.parse(localRaw) || [];
        }
      } catch (e) {
        notesFolders = [];
      }

      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([NOTES_STORAGE_KEY], (res) => {
          if (res && Array.isArray(res[NOTES_STORAGE_KEY])) {
            notesFolders = res[NOTES_STORAGE_KEY];
            try {
              localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notesFolders));
            } catch (e) {}
          }
          updateNotesBadge();
          if (callback) callback();
        });
      } else {
        updateNotesBadge();
        if (callback) callback();
      }
    }

    function saveNotesData(callback) {
      try {
        localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notesFolders));
      } catch (e) {}
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [NOTES_STORAGE_KEY]: notesFolders }, () => {
          updateNotesBadge();
          if (callback) callback();
        });
      } else {
        updateNotesBadge();
        if (callback) callback();
      }
    }

    function updateNotesBadge() {
      const badge = document.getElementById("pb-notes-badge");
      if (!badge) return;
      if (isThreadPage && threadId) {
        const tf = notesFolders.find((f) => f.id === `thread_${threadId}`);
        const count = tf && Array.isArray(tf.notes) ? tf.notes.length : 0;
        if (count > 0) {
          badge.style.display = "inline-block";
          badge.textContent = String(count);
        } else {
          badge.style.display = "none";
        }
      } else {
        const totalNotes = notesFolders.reduce((acc, f) => acc + (f.notes ? f.notes.length : 0), 0);
        if (totalNotes > 0) {
          badge.style.display = "inline-block";
          badge.textContent = String(totalNotes);
        } else {
          badge.style.display = "none";
        }
      }
    }

    function formatNowTimestamp() {
      const now = new Date();
      return now.toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit"
      });
    }

    function escapeHtml(str) {
      const d = document.createElement("div");
      d.textContent = str || "";
      return d.innerHTML;
    }

    function renderNotesPanel() {
      if (!activeFolderId) {
        renderAllFoldersView();
      } else {
        renderSingleFolderView(activeFolderId);
      }
    }

    function renderAllFoldersView() {
      const threadFolderId = isThreadPage && threadId ? `thread_${threadId}` : null;
      const threadTitle = isThreadPage ? getCleanThreadTitle() : "";

      const sortedFolders = [...notesFolders].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

      let foldersListHtml = "";
      if (sortedFolders.length === 0) {
        foldersListHtml = `<div style="color:#8b949e; font-size:12px; padding:12px 4px; text-align:center;">No note folders yet. Create one below or add a note inside any thread!</div>`;
      } else {
        foldersListHtml = sortedFolders
          .map((f) => {
            const count = f.notes ? f.notes.length : 0;
            const isCurrentThread = threadFolderId && f.id === threadFolderId;
            return `
              <div class="pb-folder-card" data-folder-id="${escapeHtml(f.id)}">
                <div class="pb-folder-info">
                  <div class="pb-folder-name">📁 ${escapeHtml(f.name)} ${isCurrentThread ? '<span style="color:#98c379;font-size:10.5px;">(Current Thread)</span>' : ""}</div>
                  <div class="pb-folder-meta">${count} note${count === 1 ? "" : "s"}</div>
                </div>
                <div style="display:flex; align-items:center; gap:6px;">
                  <button type="button" class="pb-notes-btn pb-secondary pb-open-folder-btn" data-folder-id="${escapeHtml(f.id)}">Open →</button>
                  <button type="button" class="pb-note-action-link pb-del pb-delete-folder-btn" data-folder-id="${escapeHtml(f.id)}" title="Delete folder">🗑️</button>
                </div>
              </div>
            `;
          })
          .join("");
      }

      const currentThreadShortcutHtml =
        isThreadPage && threadFolderId
          ? `<div style="margin-bottom:4px;">
               <button type="button" id="pb-jump-thread-folder-btn" class="pb-notes-btn" style="width:100%; text-align:left; display:flex; justify-content:space-between; align-items:center; padding:7px 10px !important;">
                 <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">📌 Thread Folder: ${escapeHtml(threadTitle)}</span>
                 <span>Open →</span>
               </button>
             </div>`
          : "";

      notesPanel.innerHTML = `
        <div class="pb-notes-header">
          <span class="pb-notes-title">🗂️ All Note Folders (${sortedFolders.length})</span>
          <button type="button" id="pb-notes-close-btn" class="pb-notes-btn pb-secondary">✕</button>
        </div>
        ${currentThreadShortcutHtml}
        <div class="pb-notes-scroll" id="pb-folders-list">
          ${foldersListHtml}
        </div>
        <div class="pb-notes-input-area">
          <div class="pb-notes-new-folder-row">
            <input type="text" id="pb-new-folder-input" placeholder="New folder name..." />
            <button type="button" id="pb-create-folder-btn" class="pb-notes-btn pb-success">+ New Folder</button>
          </div>
        </div>
      `;

      document.getElementById("pb-notes-close-btn").addEventListener("click", () => {
        notesPanel.style.display = "none";
      });

      const jumpBtn = document.getElementById("pb-jump-thread-folder-btn");
      if (jumpBtn) {
        jumpBtn.addEventListener("click", () => {
          activeFolderId = threadFolderId;
          editingNoteId = null;
          renderNotesPanel();
        });
      }

      notesPanel.querySelectorAll(".pb-folder-card").forEach((card) => {
        card.addEventListener("click", (e) => {
          if (e.target.closest(".pb-delete-folder-btn")) return;
          const fid = card.getAttribute("data-folder-id");
          activeFolderId = fid;
          editingNoteId = null;
          renderNotesPanel();
        });
      });

      notesPanel.querySelectorAll(".pb-delete-folder-btn").forEach((delBtn) => {
        delBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          const fid = delBtn.getAttribute("data-folder-id");
          const folder = notesFolders.find((f) => f.id === fid);
          if (!folder) return;
          if (confirm(`Delete folder "${folder.name}" and all its notes?`)) {
            notesFolders = notesFolders.filter((f) => f.id !== fid);
            saveNotesData(() => renderNotesPanel());
          }
        });
      });

      const newFolderInput = document.getElementById("pb-new-folder-input");
      const createFolderBtn = document.getElementById("pb-create-folder-btn");

      function handleCreateFolder() {
        const name = (newFolderInput.value || "").trim();
        if (!name) return;
        const newId = `folder_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        const newFolder = {
          id: newId,
          name,
          threadId: null,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          notes: []
        };
        notesFolders.push(newFolder);
        saveNotesData(() => {
          activeFolderId = newId;
          editingNoteId = null;
          renderNotesPanel();
        });
      }

      createFolderBtn.addEventListener("click", handleCreateFolder);
      newFolderInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") handleCreateFolder();
      });
    }

    function renderSingleFolderView(folderId) {
      const isCurrentThreadVirtual = isThreadPage && threadId && folderId === `thread_${threadId}`;
      let folder = notesFolders.find((f) => f.id === folderId);

      const displayFolderName = folder
        ? folder.name
        : isCurrentThreadVirtual
        ? getCleanThreadTitle()
        : "Notes Folder";

      const notesList = folder && Array.isArray(folder.notes) ? folder.notes : [];

      let notesHtml = "";
      if (notesList.length === 0) {
        notesHtml = `<div style="color:#8b949e; font-size:12px; padding:14px 6px; text-align:center;">
          ${
            isCurrentThreadVirtual && !folder
              ? `No notes for this thread yet.<br/>Write a note below and click <b>Add Note</b> to automatically create the <b>"${escapeHtml(displayFolderName)}"</b> folder!`
              : "No notes in this folder yet. Add your first note/comment below!"
          }
        </div>`;
      } else {
        notesHtml = notesList
          .map((note) => {
            if (editingNoteId === note.id) {
              return `
                <div class="pb-note-card" data-note-id="${escapeHtml(note.id)}">
                  <div class="pb-note-card-top">
                    <span>Editing Note (${escapeHtml(note.createdAt || "")})</span>
                  </div>
                  <textarea class="pb-notes-textarea" id="pb-edit-note-textarea">${escapeHtml(note.text)}</textarea>
                  <div style="display:flex; justify-content:flex-end; gap:6px;">
                    <button type="button" class="pb-notes-btn pb-secondary" id="pb-cancel-edit-note-btn">Cancel</button>
                    <button type="button" class="pb-notes-btn pb-success" id="pb-save-edit-note-btn" data-note-id="${escapeHtml(note.id)}">Save Changes</button>
                  </div>
                </div>
              `;
            }
            return `
              <div class="pb-note-card" data-note-id="${escapeHtml(note.id)}">
                <div class="pb-note-card-top">
                  <span>${escapeHtml(note.createdAt || "")}${note.editedAt ? " (edited)" : ""}</span>
                  <div class="pb-note-actions">
                    <button type="button" class="pb-note-action-link pb-edit-note-btn" data-note-id="${escapeHtml(note.id)}">Edit</button>
                    <button type="button" class="pb-note-action-link pb-del pb-delete-note-btn" data-note-id="${escapeHtml(note.id)}">Delete</button>
                  </div>
                </div>
                <div class="pb-note-text">${escapeHtml(note.text)}</div>
              </div>
            `;
          })
          .join("");
      }

      notesPanel.innerHTML = `
        <div class="pb-notes-header">
          <button type="button" id="pb-back-all-folders-btn" class="pb-notes-btn pb-secondary" title="Return to full note page">← All Folders</button>
          <span class="pb-notes-title" title="${escapeHtml(displayFolderName)}">📁 ${escapeHtml(displayFolderName)}</span>
          <button type="button" id="pb-notes-close-btn" class="pb-notes-btn pb-secondary">✕</button>
        </div>
        <div class="pb-notes-scroll" id="pb-notes-list-scroll">
          ${notesHtml}
        </div>
        <div class="pb-notes-input-area">
          <textarea class="pb-notes-textarea" id="pb-new-note-textarea" placeholder="Write a note or comment for this folder..."></textarea>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:10.5px; color:#8b949e;">Tip: Press Ctrl+Enter to quick-save</span>
            <button type="button" id="pb-add-note-btn" class="pb-notes-btn pb-success">+ Add Note</button>
          </div>
        </div>
      `;

      document.getElementById("pb-notes-close-btn").addEventListener("click", () => {
        notesPanel.style.display = "none";
      });

      document.getElementById("pb-back-all-folders-btn").addEventListener("click", () => {
        activeFolderId = null;
        editingNoteId = null;
        renderNotesPanel();
      });

      // Edit Note handlers
      notesPanel.querySelectorAll(".pb-edit-note-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          editingNoteId = btn.getAttribute("data-note-id");
          renderNotesPanel();
        });
      });

      const cancelEditBtn = document.getElementById("pb-cancel-edit-note-btn");
      if (cancelEditBtn) {
        cancelEditBtn.addEventListener("click", () => {
          editingNoteId = null;
          renderNotesPanel();
        });
      }

      const saveEditBtn = document.getElementById("pb-save-edit-note-btn");
      if (saveEditBtn) {
        saveEditBtn.addEventListener("click", () => {
          const nid = saveEditBtn.getAttribute("data-note-id");
          const editArea = document.getElementById("pb-edit-note-textarea");
          const newText = (editArea ? editArea.value : "").trim();
          if (!newText || !folder) return;
          const targetNote = folder.notes.find((n) => n.id === nid);
          if (targetNote) {
            targetNote.text = newText;
            targetNote.editedAt = formatNowTimestamp();
            folder.updatedAt = Date.now();
            editingNoteId = null;
            saveNotesData(() => renderNotesPanel());
          }
        });
      }

      // Delete Note handlers
      notesPanel.querySelectorAll(".pb-delete-note-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const nid = btn.getAttribute("data-note-id");
          if (!folder) return;
          folder.notes = folder.notes.filter((n) => n.id !== nid);
          folder.updatedAt = Date.now();
          saveNotesData(() => renderNotesPanel());
        });
      });

      // Add New Note (automatically creates the Thread Folder if in a thread and folder doesn't exist yet!)
      const newNoteTextarea = document.getElementById("pb-new-note-textarea");
      const addNoteBtn = document.getElementById("pb-add-note-btn");

      function handleAddNote() {
        const text = (newNoteTextarea.value || "").trim();
        if (!text) return;

        if (!folder) {
          folder = {
            id: folderId,
            name: displayFolderName,
            threadId: isCurrentThreadVirtual ? threadId : null,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            notes: []
          };
          notesFolders.push(folder);
        } else if (isCurrentThreadVirtual) {
          // Keep thread folder name synced with thread title
          const latestTitle = getCleanThreadTitle();
          if (latestTitle) folder.name = latestTitle;
        }

        const newNote = {
          id: `note_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          text,
          createdAt: formatNowTimestamp(),
          editedAt: null
        };

        folder.notes.push(newNote);
        folder.updatedAt = Date.now();

        saveNotesData(() => {
          renderNotesPanel();
          const scroller = document.getElementById("pb-notes-list-scroll");
          if (scroller) scroller.scrollTop = scroller.scrollHeight;
        });
      }

      addNoteBtn.addEventListener("click", handleAddNote);
      newNoteTextarea.addEventListener("keydown", (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
          e.preventDefault();
          handleAddNote();
        }
      });
    }

    // Toggle Notes Panel on bottom-left Notes button click
    notesBtn.addEventListener("click", () => {
      const isVisible = notesPanel.style.display === "flex";
      if (isVisible) {
        notesPanel.style.display = "none";
        return;
      }
      // Hide Search toolbar if open so panels don't overlap
      const searchToolbar = document.getElementById("pb-iso-toolbar");
      if (searchToolbar) searchToolbar.style.display = "none";

      loadNotesData(() => {
        // If in a thread, automatically take user to the thread's folder view!
        if (isThreadPage && threadId) {
          activeFolderId = `thread_${threadId}`;
        } else {
          activeFolderId = null;
        }
        editingNoteId = null;
        notesPanel.style.display = "flex";
        renderNotesPanel();
      });
    });

    loadNotesData();

    // ==========================================
    // Search, ISO, Day Filter & Multi-Quote Panel
    // ==========================================
    const toolbar = document.createElement("div");
    toolbar.id = "pb-iso-toolbar";

    if (!isThreadPage) {
      toolbar.innerHTML = `
        <div class="pb-iso-header">
          <span>PS-Mafia ISO, Search &amp; Multi-Quote</span>
          <button id="pb-iso-close-btn" class="pb-secondary-btn">✕</button>
        </div>
        <div style="font-size:12px; color:#ccc; line-height:1.4;">
          Open any <b>Sign-up or Game Thread</b> on PS-Mafia to scan pages, ISO players, filter by Day, search keywords, and Multi-Quote posts.
        </div>
      `;
      (document.body || document.documentElement).appendChild(toolbar);
      launcher.addEventListener("click", () => {
        const isVisible = toolbar.style.display === "flex";
        if (!isVisible) notesPanel.style.display = "none";
        toolbar.style.display = isVisible ? "none" : "flex";
      });
      document.getElementById("pb-iso-close-btn").addEventListener("click", () => {
        toolbar.style.display = "none";
      });
      return;
    }

    toolbar.innerHTML = `
      <div class="pb-iso-header">
        <span>PS-Mafia ISO &amp; Search</span>
        <div style="display:flex; gap:6px; align-items:center;">
          <span id="pb-iso-status"></span>
          <button id="pb-iso-close-btn" class="pb-secondary-btn" title="Hide panel">✕</button>
        </div>
      </div>

      <div id="pb-iso-row" class="pb-iso-row pb-iso-tinted" title="Scanning thread for ISO...">
        <select id="pb-player-select">
          <option value="">-- Select Player --</option>
        </select>
        <select id="pb-day-select" title="Filter posts by Day">
          <option value="">All Days</option>
        </select>
        <button id="pb-run-iso-btn">ISO (0%)</button>
      </div>

      <div class="pb-iso-row">
        <input type="text" id="pb-search-input" placeholder="Keyword / vote filter (optional)..." />
        <button id="pb-run-search-btn">Search</button>
      </div>

      <div class="pb-mq-section">
        <div class="pb-mq-title">
          <span id="pb-mq-count-label">Multi-Quote Queue: 0 posts</span>
          <label style="font-weight:normal; color:#abb2bf; font-size:11px; cursor:pointer;">
            <input type="checkbox" id="pb-strip-nested" checked style="vertical-align:middle;" /> Strip nested quotes
          </label>
        </div>
        <div class="pb-iso-row">
          <button id="pb-mq-insert-btn" class="pb-success-btn" style="flex:1;" title="Inserts quotes directly into reply box">Insert in Reply</button>
          <button id="pb-mq-copy-btn" style="flex:1;">Copy BBCode</button>
          <button id="pb-mq-view-btn" class="pb-secondary-btn">View</button>
          <button id="pb-mq-clear-btn" class="pb-danger-btn">Clear</button>
        </div>
      </div>
    `;

    const resultsBox = document.createElement("div");
    resultsBox.id = "pb-iso-results";

    const mountTarget = document.body || document.documentElement;
    mountTarget.appendChild(toolbar);
    mountTarget.appendChild(resultsBox);

    const mqBadge = document.getElementById("pb-mq-badge");
    const mqCountLabel = document.getElementById("pb-mq-count-label");
    const stripNestedCheckbox = document.getElementById("pb-strip-nested");
    const isoRow = document.getElementById("pb-iso-row");
    const playerSelect = document.getElementById("pb-player-select");
    const daySelect = document.getElementById("pb-day-select");
    const runIsoBtn = document.getElementById("pb-run-iso-btn");
    const searchInput = document.getElementById("pb-search-input");
    const runSearchBtn = document.getElementById("pb-run-search-btn");
    const closeBtn = document.getElementById("pb-iso-close-btn");
    const statusSpan = document.getElementById("pb-iso-status");
    const refreshToast = document.getElementById("pb-refresh-toast");

    let cachedPosts = null;
    let pagePostsMap = {};
    let availableDays = [1];
    let dayCountsMap = { 1: 0 };
    let lastScannedMaxPage = 1;
    let scanPromise = null;
    let isScanComplete = false;
    let currentScanPct = 0;
    let activeFilterState = { player: "", keyword: "", day: "" };

    function updateIsoTintState(completed, pct = 0) {
      isScanComplete = completed;
      currentScanPct = pct;

      if (isoRow && runIsoBtn) {
        if (completed) {
          isoRow.classList.remove("pb-iso-tinted");
          isoRow.title = "Thread 100% scanned — Ready to ISO!";
          runIsoBtn.textContent = "ISO Player";
        } else {
          isoRow.classList.add("pb-iso-tinted");
          isoRow.title = `Scanning thread (${pct}%) — ISO is tinted until 100% complete`;
          runIsoBtn.textContent = `ISO (${pct}%)`;
        }
      }

      document.querySelectorAll(".pb-inline-iso-btn").forEach((btn) => {
        const author = btn.getAttribute("data-pb-author") || "Player";
        if (completed) {
          btn.classList.remove("pb-iso-tinted");
          btn.title = `Isolate all posts by ${author} (100% scanned)`;
        } else {
          btn.classList.add("pb-iso-tinted");
          btn.title = `Scanning thread (${pct}%) — Click to ISO ${author} once 100% complete`;
        }
      });
    }

    launcher.addEventListener("click", () => {
      const isVisible = toolbar.style.display === "flex";
      if (!isVisible) notesPanel.style.display = "none";
      toolbar.style.display = isVisible ? "none" : "flex";
    });

    closeBtn.addEventListener("click", () => {
      toolbar.style.display = "none";
    });

    function isPostInMq(postKey) {
      return getMqQueue().some((item) => item.key === postKey);
    }

    function getCleanPostMessageHtml(postEl) {
      const msgEl =
        postEl.querySelector("div.message") ||
        postEl.querySelector(".message") ||
        postEl.querySelector(".content article");

      if (!msgEl) return { html: "", text: "", announcedDay: null };

      const cleanedClone = cleanMessageClone(msgEl);
      const announcedDay = detectAnnouncedDayFromUnquotedMessage(cleanedClone);

      cleanedClone.querySelectorAll("blockquote, .quote").forEach((q) => {
        q.classList.add("pb-quote-box");
      });

      return {
        html: cleanedClone.innerHTML,
        text: sanitizeRawQuoteText(cleanedClone.textContent || ""),
        announcedDay
      };
    }

    function togglePostInMq(postObj, customSelectedText = "") {
      let queue = getMqQueue();
      const existsIdx = queue.findIndex((item) => item.key === postObj.key);

      if (existsIdx > -1 && !customSelectedText) {
        queue.splice(existsIdx, 1);
      } else {
        const stripNested = stripNestedCheckbox ? stripNestedCheckbox.checked : true;
        const bbcode = customSelectedText
          ? sanitizeRawQuoteText(customSelectedText)
          : htmlToBBCode(postObj.html, stripNested);

        const newItem = {
          key: postObj.key,
          postId: postObj.postId,
          page: postObj.page,
          day: postObj.day || 1,
          author: postObj.author,
          usernameAttr: postObj.usernameAttr,
          timestamp: postObj.timestamp,
          url: postObj.url,
          html: postObj.html,
          bbcode: bbcode
        };

        if (existsIdx > -1) {
          queue[existsIdx] = newItem;
        } else {
          queue.push(newItem);
        }
      }

      saveMqQueue(queue);
    }

    function updateMqUI() {
      const queue = getMqQueue();
      if (queue.length > 0) {
        if (mqBadge) {
          mqBadge.style.display = "inline-block";
          mqBadge.textContent = `MQ: ${queue.length}`;
        }
      } else {
        if (mqBadge) mqBadge.style.display = "none";
      }
      if (mqCountLabel) {
        mqCountLabel.textContent = `Multi-Quote Queue: ${queue.length} post${queue.length === 1 ? "" : "s"}`;
      }

      document.querySelectorAll("[data-pb-mq-key]").forEach((btn) => {
        const key = btn.getAttribute("data-pb-mq-key");
        const active = isPostInMq(key);
        if (active) {
          btn.classList.add("pb-mq-active");
          btn.textContent = btn.classList.contains("pb-card-mq-btn") ? "✓ Quoted" : "✓ MQ";
        } else {
          btn.classList.remove("pb-mq-active");
          btn.textContent = btn.classList.contains("pb-card-mq-btn") ? "+ Multi-Quote" : "+MQ";
        }
      });
    }

    function getBaseThreadUrl() {
      const match = window.location.href.match(/(https?:\/\/[^?#]+\/thread\/\d+(?:\/[^/?#]+)?)/i);
      if (match) return match[1];
      if (threadIdMatch) {
        return `${window.location.origin}/thread/${threadIdMatch[1]}`;
      }
      return window.location.origin + window.location.pathname;
    }

    function getCurrentPageNum() {
      const m = window.location.search.match(/[?&]page=(\d+)/i);
      return m ? parseInt(m[1], 10) : 1;
    }

    function getMaxPageFromDoc(doc = document) {
      let max = 1;
      const scripts = doc.querySelectorAll("script");
      for (const s of scripts) {
        const text = s.textContent || "";
        const totalMatch = text.match(/\['lm_total',\s*"?(\d+)"?\]/);
        const limitMatch = text.match(/\['lm_limit',\s*"?(\d+)"?\]/);
        if (totalMatch && limitMatch) {
          const total = parseInt(totalMatch[1], 10);
          const limit = parseInt(limitMatch[1], 10);
          if (limit > 0) {
            const calc = Math.ceil(total / limit);
            if (calc > max) max = calc;
          }
        }
      }

      const pageEls = doc.querySelectorAll(".ui-pagination a, .ui-pagination li");
      pageEls.forEach((el) => {
        const txt = parseInt((el.textContent || "").trim(), 10);
        if (!isNaN(txt) && txt > max) max = txt;
        if (el.href) {
          const m = el.href.match(/[?&]page=(\d+)/);
          if (m) {
            const p = parseInt(m[1], 10);
            if (p > max) max = p;
          }
        }
      });

      return max;
    }

    function extractPostId(post, fallbackPage, idx) {
      if (post.id) {
        const idMatch = post.id.match(/(\d+)/);
        if (idMatch) return idMatch[1];
      }
      const postLink = post.querySelector("a[href*='/post/'], a[href*='#post-']");
      if (postLink) {
        const rawHref = postLink.getAttribute("href") || "";
        const m = rawHref.match(/(?:\/post\/|#post-)(\d+)/i);
        if (m && m[1]) return m[1];
      }
      const anchor = post.querySelector("[id^='post-'], a[name^='post-']");
      if (anchor) {
        const rawId = anchor.getAttribute("id") || anchor.getAttribute("name") || "";
        const m = rawId.match(/(\d+)/);
        if (m && m[1]) return m[1];
      }
      return `p${fallbackPage}_${idx}`;
    }

    function extractPostsFromDoc(doc, pageNum, pageUrl) {
      const results = [];
      const postRows = doc.querySelectorAll("tr.post, tr.item.post");

      postRows.forEach((post, idx) => {
        const postId = extractPostId(post, pageNum, idx);
        const key = `post_${postId}`;
        
        const info = parseAuthorAndUsername(post);
        const author = info.author;
        const usernameAttr = info.username;
        const numericUserId = info.numericUserId;

        const timeEl = post.querySelector(".content-head .date, abbr.time, .time");
        const timestamp = timeEl ? timeEl.textContent.trim() : "";

        let postUrl = pageUrl;
        if (/^\d+$/.test(String(postId))) {
          postUrl = `${window.location.origin}/post/${postId}/thread`;
        } else {
          const linkEl = post.querySelector("a[href*='/post/']");
          if (linkEl && linkEl.getAttribute("href")) {
            postUrl = new URL(linkEl.getAttribute("href"), window.location.origin).href;
          } else if (postId) {
            postUrl = `${pageUrl}#post-${postId}`;
          }
        }

        const { html: formattedHtml, text: rawText, announcedDay } = getCleanPostMessageHtml(post);

        results.push({
          key,
          postId,
          page: pageNum,
          announcedDay,
          day: 1,
          author,
          authorLower: author.toLowerCase(),
          usernameAttr,
           numericUserId,
          usernameLower: usernameAttr.toLowerCase(),
          timestamp,
          url: postUrl,
          html: formattedHtml,
          text: rawText,
          textLower: rawText.toLowerCase()
        });
      });

      return results;
    }

    function rebuildFlatCacheFromMap(maxP) {
      const combined = [];
      const seenKeys = new Set();
      let currentDay = 1;
      const dCounts = {};

      for (let p = 1; p <= maxP; p++) {
        const list = pagePostsMap[p] || [];
        for (const item of list) {
          if (seenKeys.has(item.key)) continue;
          seenKeys.add(item.key);

          if (
            item.announcedDay &&
            item.announcedDay > currentDay &&
            item.announcedDay <= currentDay + 3
          ) {
            currentDay = item.announcedDay;
          }

          item.day = currentDay;
          dCounts[currentDay] = (dCounts[currentDay] || 0) + 1;

          // If numeric username ID was resolved in cache, apply it
          if (item.usernameAttr && /^@\d+$/.test(item.usernameAttr)) {
            const uid = item.usernameAttr.replace("@", "");
            if (usernameCache[uid]) {
              item.usernameAttr = usernameCache[uid];
            }
          }

          if (item.postId && /^\d+$/.test(String(item.postId))) {
            item.url = `${window.location.origin}/post/${item.postId}/thread`;
          }
          item.authorLower = (item.author || "").toLowerCase();
          item.usernameLower = (item.usernameAttr || "").toLowerCase();
          if (!item.textLower) item.textLower = (item.text || "").toLowerCase();

          combined.push(item);
        }
      }

      dayCountsMap = dCounts;
      availableDays = Object.keys(dCounts)
        .map(Number)
        .sort((a, b) => a - b);
      if (availableDays.length === 0) availableDays = [1];

      cachedPosts = combined;
      updatePlayerDropdown(cachedPosts);
      updateDayDropdown();
      return combined;
    }

    function updateDayDropdown() {
      if (!daySelect) return;
      const curVal = daySelect.value;
      daySelect.innerHTML = `<option value="">All Days (${availableDays.length}d)</option>`;
      availableDays.forEach((d) => {
        const opt = document.createElement("option");
        opt.value = String(d);
        opt.textContent = `Day ${d} (${dayCountsMap[d] || 0})`;
        daySelect.appendChild(opt);
      });
      if (curVal && availableDays.includes(parseInt(curVal, 10))) {
        daySelect.value = curVal;
      }
    }

    function updatePlayerDropdown(posts) {
      const counts = {};
      posts.forEach((p) => {
        if (!p.author || p.author === "Unknown" || p.author === "Guest/Deleted") return;
        counts[p.author] = (counts[p.author] || 0) + 1;
      });

      const currentVal = playerSelect.value;
      const sortedPlayers = Object.keys(counts).sort((a, b) => counts[b] - counts[a]);

      playerSelect.innerHTML = `<option value="">-- Select Player (${sortedPlayers.length}) --</option>`;
      sortedPlayers.forEach((player) => {
        const opt = document.createElement("option");
        opt.value = player;
        opt.textContent = `${player} (${counts[player]} posts)`;
        playerSelect.appendChild(opt);
      });

      if (currentVal && counts[currentVal]) {
        playerSelect.value = currentVal;
      }
    }

    // Inject @username badge, [ISO], and [+MQ] onto forum posts
    let isInjecting = false;
    function injectInlinePostButtons() {
      mountLauncher();
      if (isInjecting) return;
      const unformattedPosts = document.querySelectorAll("tr.post:not([data-pb-injected]), tr.item.post:not([data-pb-injected])");
      if (unformattedPosts.length === 0) return;

      isInjecting = true;
      const curPage = getCurrentPageNum();

      unformattedPosts.forEach((post, idx) => {
        post.setAttribute("data-pb-injected", "true");
        const mp = post.querySelector(".mini-profile");
        if (!mp || mp.querySelector(".pb-inline-btn")) return;

        const info = parseAuthorAndUsername(post);
        const authorName = info.author;
        const usernameAttr = info.username;
        const numericUserId = info.numericUserId;
        const targetEl = info.authorEl || mp;

        const postId = extractPostId(post, curPage, idx);
        const key = `post_${postId}`;
        const timeEl = post.querySelector(".content-head .date, abbr.time, .time");
        const timestamp = timeEl ? timeEl.textContent.trim() : "";
        const { html } = getCleanPostMessageHtml(post);
        const postUrl = /^\d+$/.test(String(postId))
          ? `${window.location.origin}/post/${postId}/thread`
          : `${window.location.href.split("#")[0]}#post-${postId}`;

        // 1. Nice @username handle badge directly under the display name
        const userBadgeWrap = document.createElement("div");
        const userBadge = document.createElement("span");
        userBadge.className = "pb-username-badge";
        userBadge.title = "User's actual login handle";
        if (numericUserId && /^@\d+$/.test(usernameAttr)) {
          userBadge.setAttribute("data-pb-uid", numericUserId);
          userBadge.textContent = usernameCache[numericUserId] || "@...";
          resolveUsernameFromUserId(numericUserId, authorName);
        } else {
          userBadge.textContent = usernameAttr;
        }
        userBadgeWrap.appendChild(userBadge);

        // 2. [ISO] and [+MQ] Action Buttons
        const btnWrap = document.createElement("div");
        btnWrap.style.marginTop = "4px";

        const isoBtn = document.createElement("button");
        isoBtn.type = "button";
        isoBtn.className = `pb-inline-btn pb-inline-iso-btn ${isScanComplete ? "" : "pb-iso-tinted"}`.trim();
        isoBtn.setAttribute("data-pb-author", authorName);
        isoBtn.textContent = "ISO";
        isoBtn.title = isScanComplete
          ? `Isolate all posts by ${authorName} (100% scanned)`
          : `Scanning thread (${currentScanPct}%) — Click to ISO ${authorName} once 100% complete`;

        isoBtn.addEventListener("click", async (e) => {
          e.preventDefault();
          notesPanel.style.display = "none";
          toolbar.style.display = "flex";
          await ensureThreadScanned(false);
          playerSelect.value = authorName;
          renderResults(authorName, searchInput.value.trim(), daySelect.value);
        });

        const mqBtn = document.createElement("button");
        mqBtn.type = "button";
        mqBtn.className = "pb-inline-btn pb-inline-mq-btn";
        mqBtn.setAttribute("data-pb-mq-key", key);
        mqBtn.title = "Add/Remove this post in Multi-Quote";
        mqBtn.textContent = isPostInMq(key) ? "✓ MQ" : "+MQ";
        if (isPostInMq(key)) mqBtn.classList.add("pb-mq-active");

        mqBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          try {
            const selection = window.getSelection().toString().trim();
            const currentResolvedUsername =
              numericUserId && usernameCache[numericUserId]
                ? usernameCache[numericUserId]
                : usernameAttr;
            togglePostInMq(
              {
                key,
                postId,
                page: curPage,
                author: authorName,
                usernameAttr: currentResolvedUsername,
                timestamp,
                url: postUrl,
                html
              },
              selection
            );
          } catch (err) {
            console.error("Error toggling MQ:", err);
          }
        });

        btnWrap.appendChild(isoBtn);
        btnWrap.appendChild(mqBtn);

        targetEl.insertAdjacentElement("afterend", btnWrap);
        targetEl.insertAdjacentElement("afterend", userBadgeWrap);
      });

      isInjecting = false;
    }

    let observerTimeout = null;
    const observer = new MutationObserver(() => {
      if (observerTimeout) clearTimeout(observerTimeout);
      observerTimeout = setTimeout(() => {
        injectInlinePostButtons();
        updateMqUI();
      }, 100);
    });

    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        observer.observe(document.body, { childList: true, subtree: true });
      });
    }

    // High-speed parallel background scanner (6 concurrent workers + IndexedDB cache)
    async function ensureThreadScanned(forceRefresh = false) {
      if (cachedPosts && isScanComplete && !forceRefresh) return cachedPosts;
      if (scanPromise && !forceRefresh) return scanPromise;

      scanPromise = (async () => {
        updateIsoTintState(false, currentScanPct);

        const baseUrl = getBaseThreadUrl();
        const curPageNum = getCurrentPageNum();
        let maxPage = getMaxPageFromDoc(document);
        lastScannedMaxPage = maxPage;

        let completedCount = 0;
        statusSpan.textContent = `Scanning... 0%`;

        const pagesToScan = [];
        for (let p = 1; p <= maxPage; p++) {
          pagesToScan.push(p);
        }

        let nextIdx = 0;
        const CONCURRENCY = 6;

        async function scanWorker() {
          while (nextIdx < pagesToScan.length) {
            const p = pagesToScan[nextIdx++];
            let pagePosts = null;

            if (!forceRefresh && p === curPageNum && pagePostsMap[p] && pagePostsMap[p].length > 0) {
              pagePosts = pagePostsMap[p];
            }

            if (!pagePosts && !forceRefresh && p < maxPage) {
              pagePosts = await getCachedPagePosts(p);
            }

            if (!pagePosts) {
              try {
                const pageUrl = p === 1 ? baseUrl : `${baseUrl}?page=${p}`;
                const res = await fetch(pageUrl, { credentials: "same-origin" });
                const html = await res.text();
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, "text/html");

                const discoveredMax = getMaxPageFromDoc(doc);
                if (discoveredMax > maxPage) {
                  for (let extraP = maxPage + 1; extraP <= discoveredMax; extraP++) {
                    pagesToScan.push(extraP);
                  }
                  maxPage = discoveredMax;
                  lastScannedMaxPage = maxPage;
                }

                pagePosts = extractPostsFromDoc(doc, p, pageUrl);
                if (p < maxPage && pagePosts.length > 0) {
                  setCachedPagePosts(p, pagePosts);
                }
              } catch (err) {
                console.error(`Error scanning page ${p}:`, err);
                pagePosts = [];
              }
            }

            pagePostsMap[p] = pagePosts;
            completedCount++;
            const pct = Math.min(99, Math.round((completedCount / Math.max(1, pagesToScan.length)) * 100));
            statusSpan.textContent = `Scanning... ${pct}%`;
            updateIsoTintState(false, pct);
          }
        }

        const workers = [];
        for (let w = 0; w < Math.min(CONCURRENCY, pagesToScan.length); w++) {
          workers.push(scanWorker());
        }
        await Promise.all(workers);

        const totalPosts = rebuildFlatCacheFromMap(maxPage).length;
        updateIsoTintState(true, 100);
        statusSpan.textContent = `Scanned ${totalPosts} posts (${maxPage}p)`;
        scanPromise = null;

        setTimeout(() => {
          if (statusSpan.textContent.includes("Scanned")) {
            statusSpan.textContent = "";
          }
        }, 5000);

        return cachedPosts;
      })();

      return scanPromise;
    }

    let toastTimer = null;
    function showRefreshToast(msg) {
      if (!refreshToast) return;
      refreshToast.textContent = msg;
      refreshToast.style.display = "inline";
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        refreshToast.style.display = "none";
      }, 4000);
    }

    let isLiveRefreshing = false;
    async function refreshCurrentPageAndNewPosts() {
      if (isLiveRefreshing) return;
      isLiveRefreshing = true;
      refreshBtn.classList.add("pb-refreshing");
      showRefreshToast("Checking...");

      try {
        const baseUrl = getBaseThreadUrl();
        const curPage = getCurrentPageNum();
        const curPageUrl = curPage === 1 ? baseUrl : `${baseUrl}?page=${curPage}`;

        const res = await fetch(curPageUrl, { credentials: "same-origin", cache: "no-store" });
        const html = await res.text();
        const parser = new DOMParser();
        const freshDoc = parser.parseFromString(html, "text/html");

        const existingRows = Array.from(document.querySelectorAll("tr.post, tr.item.post"));
        const postListBody =
          existingRows.length > 0
            ? existingRows[0].parentElement
            : document.querySelector("table.list.posts tbody, .posts tbody");

        const existingPostIds = new Set(
          existingRows.map((row, i) => extractPostId(row, curPage, i))
        );

        let newPostsAddedToDom = 0;
        let firstNewRow = null;

        const freshRows = Array.from(freshDoc.querySelectorAll("tr.post, tr.item.post"));
        freshRows.forEach((freshRow, idx) => {
          const pid = extractPostId(freshRow, curPage, idx);
          if (!existingPostIds.has(pid) && postListBody) {
            const importedRow = document.importNode(freshRow, true);
            importedRow.classList.add("pb-newly-loaded-post");
            postListBody.appendChild(importedRow);
            existingPostIds.add(pid);
            newPostsAddedToDom++;
            if (!firstNewRow) firstNewRow = importedRow;
          }
        });

        pagePostsMap[curPage] = extractPostsFromDoc(freshDoc, curPage, curPageUrl);

        const newMaxPage = Math.max(lastScannedMaxPage, getMaxPageFromDoc(freshDoc));
        const startCheckPage = Math.max(1, lastScannedMaxPage);

        for (let p = startCheckPage; p <= newMaxPage; p++) {
          if (p === curPage) continue;
          try {
            const pUrl = p === 1 ? baseUrl : `${baseUrl}?page=${p}`;
            const pRes = await fetch(pUrl, { credentials: "same-origin", cache: "no-store" });
            const pHtml = await pRes.text();
            const pDoc = parser.parseFromString(pHtml, "text/html");
            const pPosts = extractPostsFromDoc(pDoc, p, pUrl);
            pagePostsMap[p] = pPosts;

            if (p < newMaxPage && pPosts.length > 0) {
              setCachedPagePosts(p, pPosts);
            }

            if (p > curPage && curPage === lastScannedMaxPage && postListBody) {
              const spillRows = Array.from(pDoc.querySelectorAll("tr.post, tr.item.post"));
              spillRows.forEach((sRow, sIdx) => {
                const pid = extractPostId(sRow, p, sIdx);
                if (!existingPostIds.has(pid)) {
                  const importedRow = document.importNode(sRow, true);
                  importedRow.classList.add("pb-newly-loaded-post");
                  postListBody.appendChild(importedRow);
                  existingPostIds.add(pid);
                  newPostsAddedToDom++;
                  if (!firstNewRow) firstNewRow = importedRow;
                }
              });
            }
          } catch (e) {
            console.error(`Error refreshing page ${p}:`, e);
          }
        }

        if (newMaxPage > lastScannedMaxPage) {
          const freshPagination = freshDoc.querySelector(".ui-pagination");
          if (freshPagination) {
            document.querySelectorAll(".ui-pagination").forEach((pag) => {
              pag.innerHTML = freshPagination.innerHTML;
            });
          }
          lastScannedMaxPage = newMaxPage;
        }

        if (isScanComplete) {
          rebuildFlatCacheFromMap(newMaxPage);
        } else {
          const maxLoadedSoFar = Math.max(...Object.keys(pagePostsMap).map(Number), 1);
          rebuildFlatCacheFromMap(maxLoadedSoFar);
        }

        injectInlinePostButtons();
        updateMqUI();

        if (firstNewRow) {
          firstNewRow.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        if (newPostsAddedToDom > 0) {
          showRefreshToast(`+${newPostsAddedToDom} new post${newPostsAddedToDom === 1 ? "" : "s"}!`);
        } else {
          showRefreshToast("No new posts");
        }
      } catch (err) {
        console.error("Live refresh failed:", err);
        showRefreshToast("Refresh error");
      } finally {
        refreshBtn.classList.remove("pb-refreshing");
        isLiveRefreshing = false;
      }
    }

    refreshBtn.addEventListener("click", (e) => {
      e.preventDefault();
      refreshCurrentPageAndNewPosts();
    });

    function renderPostCards(postsArray, titleText, showDayDropdown = false) {
      resultsBox.style.display = "block";

      let daySelectHtml = "";
      if (showDayDropdown) {
        const opts = [`<option value="">All Days</option>`]
          .concat(
            availableDays.map(
              (d) =>
                `<option value="${d}" ${String(activeFilterState.day) === String(d) ? "selected" : ""}>Day ${d}</option>`
            )
          )
          .join("");
        daySelectHtml = `<select id="pb-modal-day-select" title="Filter results by Day">${opts}</select>`;
      }

      resultsBox.innerHTML = `
        <div class="pb-results-topbar">
          <strong>${titleText}</strong>
          <div style="display:flex; gap:6px; align-items:center;">
            ${daySelectHtml}
            <button id="pb-modal-copy-mq" style="background:#2ea043;color:#fff;border:none;padding:4px 8px;border-radius:4px;cursor:pointer;font-size:12px;">Insert / Copy MQ</button>
            <button id="pb-close-results" style="background:#e06c75;color:#fff;border:none;padding:4px 8px;border-radius:4px;cursor:pointer;font-size:12px;">Close ✕</button>
          </div>
        </div>
        <div id="pb-results-list"></div>
      `;

      document.getElementById("pb-close-results").addEventListener("click", () => {
        resultsBox.style.display = "none";
      });

      document.getElementById("pb-modal-copy-mq").addEventListener("click", () => {
        insertOrCopyMultiQuote();
      });

      const modalDaySelect = document.getElementById("pb-modal-day-select");
      if (modalDaySelect) {
        modalDaySelect.addEventListener("change", () => {
          daySelect.value = modalDaySelect.value;
          renderResults(activeFilterState.player, activeFilterState.keyword, modalDaySelect.value);
        });
      }

      const listEl = document.getElementById("pb-results-list");

      if (postsArray.length === 0) {
        listEl.innerHTML = `<p style="color:#aaa;">No posts found matching your filter.</p>`;
        return;
      }

      const frag = document.createDocumentFragment();
      postsArray.forEach((m, idx) => {
        const card = document.createElement("div");
        card.className = "pb-post-card";
        const active = isPostInMq(m.key);
        const dayNum = m.day || 1;

        let displayHandle = m.usernameAttr || "";
        let uidAttr = "";
        if (displayHandle && /^@\d+$/.test(displayHandle)) {
          const uid = displayHandle.replace("@", "");
          uidAttr = `data-pb-uid="${uid}"`;
          if (usernameCache[uid]) {
            displayHandle = usernameCache[uid];
          } else {
            displayHandle = "@...";
            resolveUsernameFromUserId(uid, m.author);
          }
        }

        card.innerHTML = `
          <div class="pb-post-meta">
            <span>
              <span class="pb-post-author">${escapeHtml(m.author)}</span>
              <span class="pb-card-username" ${uidAttr} title="User's login handle">${escapeHtml(displayHandle)}</span>
              <span style="color:#888; margin-left:6px;">${escapeHtml(m.timestamp || "")}</span>
            </span>
            <div style="display:flex; gap:8px; align-items:center;">
              <span class="pb-day-badge" title="Sent on Day ${dayNum}">Day ${dayNum}</span>
              <button type="button" class="pb-card-mq-btn ${active ? "pb-mq-active" : ""}" data-pb-mq-key="${m.key}">
                ${active ? "✓ Quoted" : "+ Multi-Quote"}
              </button>
              <a class="pb-post-link" href="${m.postId && /^\d+$/.test(String(m.postId)) ? `${window.location.origin}/post/${m.postId}/thread` : m.url}" target="_blank">Page ${m.page} (#${idx + 1}) ↗</a>
            </div>
          </div>
          <div class="pb-post-body">${m.html || m.bbcode}</div>
        `;

        const mqBtn = card.querySelector(".pb-card-mq-btn");
        mqBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          const selection = window.getSelection().toString().trim();
          togglePostInMq(m, selection);
        });

        frag.appendChild(card);
      });
      listEl.appendChild(frag);
    }

    function renderResults(playerFilter, keywordFilter, dayFilter = "") {
      if (!cachedPosts) return;

      activeFilterState = {
        player: playerFilter || "",
        keyword: keywordFilter || "",
        day: dayFilter || ""
      };

      const pQuery = (playerFilter || "").trim().toLowerCase();
      const kQuery = (keywordFilter || "").trim().toLowerCase();
      const dQuery = dayFilter ? parseInt(dayFilter, 10) : null;

      const matches = cachedPosts.filter((post) => {
        const matchesDay = !dQuery || (post.day || 1) === dQuery;
        if (!matchesDay) return false;

        const matchesPlayer =
          !pQuery ||
          post.authorLower === pQuery ||
          post.usernameLower.includes(pQuery) ||
          post.authorLower.includes(pQuery);
        if (!matchesPlayer) return false;

        const matchesKeyword =
          !kQuery ||
          post.textLower.includes(kQuery) ||
          post.authorLower.includes(kQuery);

        return matchesKeyword;
      });

      const daySuffix = dQuery ? ` [Day ${dQuery}]` : "";
      let titleText = "";
      if (pQuery) {
        titleText = `ISO: ${playerFilter}${daySuffix} (${matches.length} posts${kQuery ? ` matching "${keywordFilter}"` : ""})`;
      } else if (kQuery) {
        titleText = `Search: "${keywordFilter}"${daySuffix} (${matches.length} posts)`;
      } else if (dQuery) {
        titleText = `Day ${dQuery} Posts (${matches.length} posts)`;
      } else {
        titleText = `All Posts (${matches.length} posts)`;
      }

      renderPostCards(matches, titleText, true);
    }

    async function insertOrCopyMultiQuote(copyOnly = false) {
      const queue = getMqQueue();
      if (queue.length === 0) {
        alert("Your Multi-Quote queue is empty! Click '+MQ' on any posts first.");
        return;
      }

      statusSpan.textContent = "Formatting quotes...";
      const bbcodeText = await buildAllQuotesBBCode();
      statusSpan.textContent = "";

      navigator.clipboard?.writeText(bbcodeText).catch(() => {});

      if (copyOnly) {
        statusSpan.textContent = `Copied ${queue.length} quotes!`;
        setTimeout(() => (statusSpan.textContent = ""), 3000);
        return;
      }

      const replyBox = document.querySelector(
        "textarea[name='message'], .form_post_quick_reply textarea, .quick-reply textarea, .ui-wysiwyg textarea, textarea"
      );

      if (replyBox) {
        const existing = replyBox.value.trim();
        replyBox.value = existing ? `${existing}\n\n${bbcodeText}` : bbcodeText;
        
        replyBox.dispatchEvent(new Event("input", { bubbles: true }));
        replyBox.dispatchEvent(new Event("change", { bubbles: true }));
        replyBox.dispatchEvent(new Event("keyup", { bubbles: true }));
        
        replyBox.scrollIntoView({ behavior: "smooth", block: "center" });
        replyBox.focus();
        statusSpan.textContent = `Inserted ${queue.length} quotes!`;
      } else {
        alert(`Copied ${queue.length} quotes to your clipboard! Paste (Ctrl+V) them into your reply box.`);
      }
    }

    // Initial setup
    const curPageNum = getCurrentPageNum();
    const currentPagePosts = extractPostsFromDoc(document, curPageNum, window.location.href);
    pagePostsMap[curPageNum] = currentPagePosts;
    updatePlayerDropdown(currentPagePosts);
    updateDayDropdown();
    updateIsoTintState(false, 0);
    injectInlinePostButtons();
    updateMqUI();
    
    ensureThreadScanned(false);

    runIsoBtn.addEventListener("click", async () => {
      const selectedPlayer = playerSelect.value || searchInput.value.trim();
      const selectedDay = daySelect.value;
      if (!selectedPlayer && !selectedDay) {
        alert("Select a player or a Day from the dropdown first!");
        return;
      }
      await ensureThreadScanned(false);
      renderResults(selectedPlayer, searchInput.value.trim(), selectedDay);
    });

    runSearchBtn.addEventListener("click", async () => {
      const kw = searchInput.value.trim();
      const selectedPlayer = playerSelect.value;
      const selectedDay = daySelect.value;
      if (!kw && !selectedPlayer && !selectedDay) return;
      await ensureThreadScanned(false);
      renderResults(selectedPlayer, kw, selectedDay);
    });

    daySelect.addEventListener("change", async () => {
      if (resultsBox.style.display === "block" && !resultsBox.innerHTML.includes("Multi-Quote Queue")) {
        await ensureThreadScanned(false);
        renderResults(playerSelect.value, searchInput.value.trim(), daySelect.value);
      }
    });

    searchInput.addEventListener("keydown", (e) => {
      e.key === "Enter" && runSearchBtn.click();
    });

    document.getElementById("pb-mq-insert-btn").addEventListener("click", async () => {
      await insertOrCopyMultiQuote(false);
    });

    document.getElementById("pb-mq-copy-btn").addEventListener("click", async () => {
      await insertOrCopyMultiQuote(true);
    });

    document.getElementById("pb-mq-view-btn").addEventListener("click", () => {
      const queue = getMqQueue();
      renderPostCards(queue, `Multi-Quote Queue (${queue.length} posts)`, false);
    });

    document.getElementById("pb-mq-clear-btn").addEventListener("click", () => {
      saveMqQueue([]);
      if (resultsBox.style.display === "block" && resultsBox.innerHTML.includes("Multi-Quote Queue")) {
        renderPostCards([], "Multi-Quote Queue (0 posts)", false);
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initExtension);
  } else {
    initExtension();
  }
})();
